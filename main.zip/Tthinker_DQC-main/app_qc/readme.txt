graph.h: normal version
graph_ablation.h: ablation experiment version
